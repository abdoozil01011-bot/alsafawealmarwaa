-- شغّل الملف ده مرة واحدة في Supabase > SQL Editor.
-- مهم: الـ Bucket لازم يكون اسمه بالضبط: products-images
-- الملف آمن لإعادة التشغيل لأنه يحذف السياسات القديمة بنفس الأسماء ثم ينشئها من جديد.

-- ===== PRODUCTS: CRUD =====
drop policy if exists "Public can view products" on public.products;
drop policy if exists "Authenticated can insert products" on public.products;
drop policy if exists "Authenticated can update products" on public.products;
drop policy if exists "Authenticated can delete products" on public.products;

create policy "Public can view products"
on public.products
for select
to anon, authenticated
using (true);

create policy "Authenticated can insert products"
on public.products
for insert
to authenticated
with check (true);

create policy "Authenticated can update products"
on public.products
for update
to authenticated
using (true)
with check (true);

create policy "Authenticated can delete products"
on public.products
for delete
to authenticated
using (true);

-- ===== STORAGE: products-images =====
drop policy if exists "Public can view product images" on storage.objects;
drop policy if exists "Authenticated can upload product images" on storage.objects;
drop policy if exists "Authenticated can update product images" on storage.objects;
drop policy if exists "Authenticated can delete product images" on storage.objects;

create policy "Public can view product images"
on storage.objects
for select
to public
using (bucket_id = 'products-images');

create policy "Authenticated can upload product images"
on storage.objects
for insert
to authenticated
with check (bucket_id = 'products-images');

create policy "Authenticated can update product images"
on storage.objects
for update
to authenticated
using (bucket_id = 'products-images')
with check (bucket_id = 'products-images');

create policy "Authenticated can delete product images"
on storage.objects
for delete
to authenticated
using (bucket_id = 'products-images');
