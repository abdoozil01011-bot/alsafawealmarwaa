# تحديث موقع لحوم الصفا والمروة

## قبل الرفع على GitHub
1. افتح Supabase > Storage وتأكد أن الـ Bucket اسمه `products-images` وموجود.
2. افتح SQL Editor وشغّل محتوى `STORAGE_POLICIES.sql` بالكامل، ثم يجب أن تظهر سياسات للـ Bucket ولسجل products.
3. ارفع ملفات المشروع إلى GitHub واستبدل الملفات القديمة.
4. افتح `admin.html` وسجّل الدخول ثم جرّب إضافة صنف بصورة، ثم تعديل وحذف.

ملحوظة: لا تغيّر مفتاح Supabase الـ publishable الموجود في `supabase-config.js`. لا تضع service_role key داخل الموقع.
